from django.apps import AppConfig


class TeammanagerConfig(AppConfig):
    name = 'teammanager'
